package SpringApplication.Truck.AppService;

import SpringApplication.Truck.AppModel.Truck;
import SpringApplication.Truck.Exception.TruckDetailsAlreadyExistsException;
import SpringApplication.Truck.Exception.TruckDetailsNotFoundException;
import org.springframework.http.ResponseEntity;

import javax.swing.text.html.parser.Entity;
import java.util.List;

public interface ItruckService {
    Truck createTruck(Truck truck) throws TruckDetailsAlreadyExistsException;

    ResponseEntity<Truck> updateTruckDetails(long truckNumber, Truck truck) throws TruckDetailsNotFoundException;

    void deleteTruckDetails(long truckNumber) throws TruckDetailsNotFoundException;

    List<Truck> getAllTruck();
    public ResponseEntity<Truck> getTRuckDetailsById(long truckNumber) throws TruckDetailsNotFoundException;
}
