package SpringApplication.Truck.AppService;

import SpringApplication.Truck.AppModel.Truck;
import SpringApplication.Truck.AppRepository.TruckRepository;
import SpringApplication.Truck.Exception.TruckDetailsAlreadyExistsException;
import SpringApplication.Truck.Exception.TruckDetailsNotFoundException;
import SpringApplication.Truck.TruckApplication;
import org.omg.CORBA.TRANSACTION_MODE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TruckserviceImpl implements ItruckService {


    @Autowired
    TruckRepository truckRepository;

    private String exceptionMsgForBlogAlreadyAvailable;

    private String exceptionMsgForBlogNotFound;
    public Truck createTruck(Truck truck) throws TruckDetailsAlreadyExistsException {
        if(truckRepository.findById(truck.getTruckNumber()).isPresent())
        {

            throw new TruckDetailsAlreadyExistsException(exceptionMsgForBlogAlreadyAvailable);
        }
        return truckRepository.save(truck);
    }


    @Override
    public ResponseEntity<Truck> getTRuckDetailsById(long truckNumber) throws TruckDetailsNotFoundException {
        Truck truck = truckRepository.findById(truckNumber)
                .orElseThrow(() -> new TruckDetailsNotFoundException("Truck Details not found for this TruckNumber :: " + truckNumber));
        return ResponseEntity.ok().body(truck);

    }

    @Override
    public ResponseEntity<Truck> updateTruckDetails(long truckNumber, Truck truck) throws TruckDetailsNotFoundException {
        Truck trck = truckRepository.findById(truckNumber)
                .orElseThrow(() -> new TruckDetailsNotFoundException("Truck not found for this truckNumber :: " + truckNumber));

        trck.setTruckNumber(trck.getTruckNumber());
        trck.setTruckName(trck.getTruckName());
        trck.setTruckType(trck.getTruckType());
        final Truck updatedTruck = truckRepository.save(trck);
        return ResponseEntity.ok(updatedTruck);
    }

    @Override
    public void deleteTruckDetails(long truckNumber)
            throws TruckDetailsNotFoundException {
        Truck truck = truckRepository.findById(truckNumber).orElseThrow(() -> new TruckDetailsNotFoundException("Truck  not found for this truckNumber :: " + truckNumber));

        truckRepository.delete(truck);

    }

    @Override
    public List<Truck> getAllTruck() {
        return (List<Truck>) truckRepository.findAll();
    }

}

